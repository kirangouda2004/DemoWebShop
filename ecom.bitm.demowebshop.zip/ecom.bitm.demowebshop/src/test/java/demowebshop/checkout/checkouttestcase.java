package demowebshop.checkout;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import ecom.bitm.demowebshop.baseClass.baseclass;
import ecom.bitm.demowebshop.objRepo.LoginPage;
import ecom.bitm.demowebshop.objRepo.ProductPage;
import ecom.bitm.demowebshop.objRepo.CartPage;
import ecom.bitm.demowebshop.objRepo.CheckoutPage;
import ecom.bitm.demowebshop.utility.ExcelUtility;

public class checkouttestcase extends baseclass {

    private static final String EXCEL_PATH =
            System.getProperty("user.dir")
            + "/src/test/resources/demowebshop_testdata.xlsx";

    private static final String SHEET_NAME = "CheckoutData";

    // Read the explicit wait from CommonData.properties.
    private WebDriverWait getWait() {
        int waitSeconds = Integer.parseInt(
                properties.getProperty("explicitWait", "20"));

        return new WebDriverWait(
                driver, Duration.ofSeconds(waitSeconds));
    }

    // Get the application URL without trailing slashes.
    private String getBaseUrl() {
        String baseUrl = properties.getProperty("url");

        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException(
                    "Application URL is missing in CommonData.properties");
        }

        return baseUrl.replaceAll("/+$", "") + "/";
    }

    // Read test data from Excel using the test case ID.
    private String getTestData(String testCaseID, String columnName)
            throws IOException {

        try (ExcelUtility excel =
                new ExcelUtility(EXCEL_PATH, SHEET_NAME)) {

            for (int row = 0; row < excel.getRowCount(); row++) {

                String currentID =
                        excel.getCellData(row, "TestCaseID").trim();

                if (currentID.equalsIgnoreCase(testCaseID)) {
                    return excel.getCellData(row, columnName).trim();
                }
            }
        }

        throw new IllegalArgumentException(
                "Test case not found in Excel: " + testCaseID);
    }

    // Log in using credentials stored in Excel.
    private void loginToApplication(String testCaseID)
            throws IOException {

        driver.get(getBaseUrl() + "login");

        getWait().until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.id("Email")));

        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(
                getTestData(testCaseID, "Email"),
                getTestData(testCaseID, "Password"));

        getWait().until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector("a.account")));
    }

    // Search for the Excel product and add it to the cart.
    private void addProductToCart(String testCaseID)
            throws IOException {

        String productName =
                getTestData(testCaseID, "ProductName");

        String searchUrl = getBaseUrl() + "search?q="
                + URLEncoder.encode(
                        productName, StandardCharsets.UTF_8);

        driver.get(searchUrl);

        ProductPage productPage = new ProductPage(driver);
        productPage.clickProduct(productName);

        By addToCartButton =
                By.cssSelector("input[id^='add-to-cart-button']");

        getWait().until(
                ExpectedConditions.elementToBeClickable(addToCartButton))
                .click();

        getWait().until(ExpectedConditions.or(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector(".bar-notification.success")),
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector(".bar-notification.error"))
        ));

        Assert.assertTrue(
                driver.findElements(
                        By.cssSelector(".bar-notification.success"))
                        .size() > 0,
                "Product was not added successfully.");
    }

    // Log in, add a product, open the cart, and start checkout.
    private CheckoutPage openCheckout(String testCaseID)
            throws IOException {

        loginToApplication(testCaseID);
        addProductToCart(testCaseID);

        driver.get(getBaseUrl() + "cart");

        CartPage cartPage = new CartPage(driver);

        getWait().until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector(".cart")));

        Assert.assertTrue(
                cartPage.getCartItemCount() > 0,
                "The cart must contain a product before checkout.");

        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.clickCheckout();

        getWait().until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.id("billing-address-select")));

        return checkoutPage;
    }

    // TC-CHK-01: Checkout starts from a non-empty cart.
    @Test(groups = "Integration")
    public void verifyCheckoutStartsFromNonEmptyCart()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-01");

        Assert.assertTrue(
                checkoutPage.isBillingAddressDropdownDisplayed(),
                "Checkout should open from the non-empty cart.");
    }

    // TC-CHK-02: Verify billing address fields are displayed.
    @Test(groups = "Functionality")
    public void verifyBillingAddressFieldsDisplayed()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-02");

        checkoutPage.selectBillingAddress("New Address");

        Assert.assertTrue(
                checkoutPage.areBillingFieldsDisplayed(),
                "Billing address fields should be displayed.");
    }

    // TC-CHK-03: Required billing fields cannot be skipped.
    @Test(groups = "Negative")
    public void verifyRequiredBillingFieldsCannotBeSkipped()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-03");

        checkoutPage.selectBillingAddress("New Address");
        checkoutPage.clickBillingContinue();

        Assert.assertTrue(
                checkoutPage.areBillingValidationErrorsDisplayed(),
                "Validation should appear when required billing fields are empty.");
    }

    // TC-CHK-06: Verify checkout opens without placing an order.
    @Test(groups = "System")
    public void verifyCheckoutFlowWithoutPlacingOrder()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-06");

        Assert.assertTrue(
                checkoutPage.isBillingAddressDropdownDisplayed(),
                "Checkout should remain in the checkout flow.");

        Assert.assertFalse(
                checkoutPage.isOrderCompletedDisplayed(),
                "This test must not place the final order.");
    }

    // TC-CHK-09: Verify product and total on the order review.
    // TODO: Implement the billing, shipping, and payment steps,
    // then verify the product and total on the order-review page.
    @Test(groups = "Integration")
    public void verifyProductAndTotalOnOrderReview()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-09");

        Assert.assertTrue(
                checkoutPage.isBillingAddressDropdownDisplayed(),
                "Checkout should open before proceeding to order review.");

        Assert.assertFalse(
                checkoutPage.isOrderCompletedDisplayed(),
                "The order should not be completed during this test.");
    }

    // TC-CHK-10: Complete an order successfully.
    // TODO: Implement all checkout stages and verify order confirmation.
    @Test(groups = "System")
    public void completeOrderSuccessfully()
            throws IOException {

        CheckoutPage checkoutPage = openCheckout("TC-CHK-10");

        Assert.assertTrue(
                checkoutPage.isBillingAddressDropdownDisplayed(),
                "Checkout should open before completing the order.");

        Assert.assertFalse(
                checkoutPage.isOrderCompletedDisplayed(),
                "The order should not already be completed.");
    }
}
